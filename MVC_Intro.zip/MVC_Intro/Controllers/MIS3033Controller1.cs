﻿using Microsoft.AspNetCore.Mvc;
using MVC_Intro.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_Intro.Controllers
{
    public class MIS3033Controller1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult StudentOfTheYear()
        {
            Student soty = new Student()
            {
                Firstname = "Micah",
                Lastname = "Tison"
            };


            return View(soty);  // we need to pass this 
        }
    }
}
