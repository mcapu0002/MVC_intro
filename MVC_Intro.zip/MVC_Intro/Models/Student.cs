﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_Intro.Models
{
    public class Student
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }



        public Student()
        {
            Firstname = "";
            Lastname = "";
        }
    }

}
